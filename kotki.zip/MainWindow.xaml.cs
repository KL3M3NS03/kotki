﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace kotki
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int counter = 1;

        public MainWindow()
        {
            InitializeComponent();
            First_Image_Setter();
        }

        private void First_Image_Setter()
        {
            cats_images.Width = 250;
            cats_images.Height = 200;
            BitmapImage kotki = new BitmapImage();
            kotki.BeginInit();
            kotki.UriSource = new Uri(@"C:\Users\uczen\source\repos\kotki\kotki\kot1.jpg");
            cats_images.Source = kotki;
            kotki.EndInit();
        }
        // next
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            counter++;
            cats_images.Width = 250;
            BitmapImage kotki = new BitmapImage();
            kotki.BeginInit();
            kotki.UriSource = new Uri(@"C:\Users\uczen\source\repos\kotki\kotki\kot" + counter + ".jpg");
            cats_images.Source = kotki;
            kotki.EndInit();
            if (counter == 4)
            {
                counter = 1;
            }
        }

        // prev
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (counter == 1)
            {
                counter = 4;
            }
            counter--;
            cats_images.Width = 250;
            BitmapImage kotki = new BitmapImage();
            kotki.BeginInit();
            kotki.UriSource = new Uri(@"C:\Users\uczen\source\repos\kotki\kotki\kot" + counter + ".jpg");
            cats_images.Source = kotki;
            kotki.EndInit();
        }

        private void photo_number_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (photo_number.Text == "")
            {

            }
            else if(photo_number.Text == "1" || photo_number.Text == "2" || photo_number.Text == "3" || photo_number.Text == "4")
            {
                BitmapImage kotki = new BitmapImage();
                kotki.BeginInit();
                kotki.UriSource = new Uri(@"C:\Users\uczen\source\repos\kotki\kotki\kot" + photo_number.Text + ".jpg");
                cats_images.Source = kotki;
                kotki.EndInit();
            }
        }
    }
}
